import base64
import json
import socket
import sys
import os
import time
from cryptography.fernet import Fernet, InvalidToken

HOST = "127.0.0.1"
KDC_PORT = 9000
SERVICE_PORT = 9001
CLIENT_ID = "alice"
SERVICE_ID = "printer"
LIFETIME = 5
SKEW = 30
CLIENT_KEY = base64.urlsafe_b64encode(b"A" * 32).decode()
TGS_KEY = base64.urlsafe_b64encode(b"T" * 32).decode()
SERVICE_KEY = base64.urlsafe_b64encode(b"S" * 32).decode()

def actor_name():
    name = os.path.splitext(os.path.basename(sys.argv[0]))[0]
    return {"client": "CLIENT", "kdc": "KDC (AS/TGS)", "service": "SERVICE"}.get(name, name.upper())

def log_payload(title, payload):
    print(f"\n{'=' * 75}\n[{time.strftime('%H:%M:%S')}] [{actor_name()}] {title}\n{'-' * 75}", flush=True)
    print(json.dumps(payload, indent=2, ensure_ascii=False), flush=True)
    print("=" * 75, flush=True)

def encrypt(key, value):
    return Fernet(key.encode()).encrypt(json.dumps(value).encode()).decode()

def decrypt(key, token):
    return json.loads(Fernet(key.encode()).decrypt(token.encode()))

def new_key():
    return Fernet.generate_key().decode()

def send(sock, value):
    sock.sendall((json.dumps(value) + "\n").encode())

def receive(sock):
    with sock.makefile("rb") as stream:
        line = stream.readline(65537)
    if not line or len(line) > 65536 or not line.endswith(b"\n"):
        raise ValueError("Invalid or oversized message")
    return json.loads(line)

def request(port, message):
    destination = {KDC_PORT: "KDC (AS/TGS)", SERVICE_PORT: "SERVICE"}.get(port, f"PORT {port}")
    kind = message.get("type", "UNKNOWN")
    with socket.create_connection((HOST, port), timeout=10) as sock:
        log_payload(f"SEND {kind}: {actor_name()} -> {destination}", message)
        send(sock, message)
        response = receive(sock)
        log_payload(f"RECEIVE response to {kind}: {destination} -> {actor_name()}", response)
        return response

def serve(port, handler):
    with socket.socket() as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((HOST, port))
        server.listen()
        print(f"[{actor_name()}] Listening on {HOST}:{port}", flush=True)
        while True:
            sock, peer = server.accept()
            with sock:
                sock.settimeout(10)
                kind = "UNKNOWN"
                try:
                    message = receive(sock)
                    kind = message.get("type", "UNKNOWN")
                    log_payload(f"RECEIVE {kind}: CLIENT -> {actor_name()} (peer={peer}; identity not yet verified)", message)
                    reply = handler(message)
                except InvalidToken:
                    reply = {"ok": False, "error": "Invalid encrypted token"}
                except Exception as exc:
                    reply = {"ok": False, "error": str(exc)}
                log_payload(f"SEND response to {kind}: {actor_name()} -> CLIENT", reply)
                send(sock, reply)

def check_auth(ticket, auth, audience, cache):
    # Provided reference implementation used by the TGS.
    now = time.time()
    if ticket["audience"] != audience:
        raise ValueError("Wrong ticket audience")
    if not ticket["issued"] <= now < ticket["expires"]:
        raise ValueError("Ticket expired or not yet valid")
    if auth["client"] != ticket["client"]:
        raise ValueError("Identity mismatch")
    if abs(now - auth["timestamp"]) > SKEW:
        raise ValueError("Authenticator timestamp outside allowed window")
    for entry, deadline in list(cache.items()):
        if deadline <= now:
            del cache[entry]
    entry = (ticket["session_key"], auth["client"], auth["timestamp"])
    if entry in cache:
        raise ValueError("Replay detected")
    cache[entry] = ticket["expires"]
    log_payload("VALIDATION PASSED", {"client": ticket["client"], "audience": audience})
