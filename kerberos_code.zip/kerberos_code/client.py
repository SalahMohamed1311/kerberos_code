import argparse
from common import *

def make_authenticator(session_key, identity):
    # TODO 2: Create {"client": identity, "timestamp": time.time()}.
    auth = {
        "client": identity,
        "timestamp": time.time()
    }
    
    # Log the plaintext authenticator using log_payload().
    log_payload("CLIENT: authenticator (plaintext)", auth)
    
    # Encrypt it using session_key.
    encrypted_auth = encrypt(session_key, auth)
    
    # Return (plaintext_authenticator, encrypted_authenticator).
    return auth, encrypted_auth

def unpack(response, key):
    if not response.get("ok"):
        raise ValueError(response["error"])
    return decrypt(key, response["reply"])

def main(mode):
    proof_payload = {"client": CLIENT_ID, "timestamp": time.time()}
    log_payload("CREATED AS preauthentication proof: before encryption", proof_payload)
    proof = encrypt(CLIENT_KEY, proof_payload)
    as_reply = unpack(request(KDC_PORT, {
        "type": "AS_REQ", "client": CLIENT_ID, "proof": proof,
    }), CLIENT_KEY)
    log_payload("AS REPLY: decrypted using CLIENT_KEY", as_reply)
    log_payload("RECEIVED TGT = (encrypted; client cannot decrypt this ticket)", as_reply["ticket"])
    log_payload("RECEIVED client/TGS session key =", as_reply["session_key"])
    _, tgs_auth = make_authenticator(as_reply["session_key"], CLIENT_ID)
    log_payload("TGS authenticator: encrypted value =", tgs_auth)
    tgs_reply = unpack(request(KDC_PORT, {
        "type": "TGS_REQ", "service": SERVICE_ID,
        "ticket": as_reply["ticket"], "authenticator": tgs_auth,
    }), as_reply["session_key"])
    log_payload("TGS REPLY: decrypted using client/TGS session key", tgs_reply)
    log_payload("RECEIVED service ticket = (encrypted; client cannot decrypt this ticket)", tgs_reply["ticket"])
    log_payload("RECEIVED client/service session key =", tgs_reply["session_key"])
    if mode == "expired":
        delay = max(0, tgs_reply["expires"] - time.time()) + 0.2
        print(f"Waiting {delay:.1f}s for ticket expiry...", flush=True)
        time.sleep(delay)
    identity = "mallory" if mode == "wrong-id" else CLIENT_ID
    auth, token = make_authenticator(tgs_reply["session_key"], identity)
    log_payload("SERVICE authenticator: encrypted value =", token)
    message = {"type": "AP_REQ", "ticket": tgs_reply["ticket"], "authenticator": token}
    for i in range(2 if mode == "replay" else 1):
        log_payload(f"SERVICE REQUEST: attempt {i + 1}", {
            "mode": mode,
            "note": "Resending identical ticket and authenticator" if i else "Sending ticket and authenticator",
        })
        response = request(SERVICE_PORT, message)
        if response.get("ok"):
            reply = unpack(response, tgs_reply["session_key"])
            log_payload("SERVICE REPLY: decrypted using client/service session key", reply)
            if reply["timestamp"] != auth["timestamp"]:
                raise ValueError("Service response does not match authenticator")
            print(f"Attempt {i + 1}: ACCEPTED - {reply['message']}", flush=True)
        else:
            print(f"Attempt {i + 1}: REJECTED - {response['error']}", flush=True)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["normal", "expired", "wrong-id", "replay"], default="normal")
    args = parser.parse_args()
    try:
        main(args.mode)
    except (ValueError, OSError, InvalidToken, NotImplementedError) as exc:
        print(f"ERROR: {exc}", flush=True)
        raise SystemExit(1)
