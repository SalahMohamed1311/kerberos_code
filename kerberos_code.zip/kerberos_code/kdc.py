from common import *

replay_cache = {}

def issue_ticket(client, audience, wrapping_key, reply_key, expires=None):
    # TODO 1: Generate a fresh session key using new_key().
    session_key = new_key()
    
    # Expiry = now + LIFETIME, limited by expires when it is not None.
    now = time.time()
    ticket_expires = now + LIFETIME
    if expires is not None:
        ticket_expires = min(ticket_expires, expires)
        
    # Build a ticket: client, audience, session_key, issued, expires.
    ticket = {
        "client": client,
        "audience": audience,
        "session_key": session_key,
        "issued": now,
        "expires": ticket_expires
    }
    
    # Log the plaintext ticket using log_payload().
    log_payload("KDC: issuing ticket (plaintext)", ticket)
    
    # Encrypt the ticket with wrapping_key and log its encrypted value.
    encrypted_ticket = encrypt(wrapping_key, ticket)
    log_payload("KDC: issuing ticket (encrypted)", encrypted_ticket)
    
    # Build a reply: session_key, ticket (encrypted), expires.
    reply = {
        "session_key": session_key,
        "ticket": encrypted_ticket,
        "expires": ticket_expires
    }
    
    # Log that reply before encrypting it with reply_key.
    log_payload("KDC: issuing reply (plaintext)", reply)
    encrypted_reply = encrypt(reply_key, reply)
    
    # Return {"ok": True, "reply": encrypted_reply}.
    return {"ok": True, "reply": encrypted_reply}

def handle(message):
    if message["type"] == "AS_REQ":
        if message["client"] != CLIENT_ID:
            raise ValueError("Unknown client")
        proof = decrypt(CLIENT_KEY, message["proof"])
        log_payload("AS: decrypted preauthentication proof", proof)
        if proof["client"] != CLIENT_ID or abs(time.time() - proof["timestamp"]) > SKEW:
            raise ValueError("Invalid preauthentication")
        log_payload("AS: preauthentication accepted", {"client": CLIENT_ID})
        return issue_ticket(CLIENT_ID, "tgs", TGS_KEY, CLIENT_KEY)
    if message["type"] == "TGS_REQ":
        if message["service"] != SERVICE_ID:
            raise ValueError("Unknown service")
        tgt = decrypt(TGS_KEY, message["ticket"])
        log_payload("TGS: received TGT, decrypted contents", tgt)
        auth = decrypt(tgt["session_key"], message["authenticator"])
        log_payload("TGS: received authenticator, decrypted contents", auth)
        check_auth(tgt, auth, "tgs", replay_cache)
        return issue_ticket(tgt["client"], SERVICE_ID, SERVICE_KEY, tgt["session_key"], tgt["expires"])
    raise ValueError("Unknown request type")

if __name__ == "__main__":
    serve(KDC_PORT, handle)
