from common import *

replay_cache = {}

def validate_service(ticket, auth):
    # TODO 3: Validate audience, lifetime, matching client identity,
    # timestamp freshness (SKEW), and replay protection.
    
    # 1. Validate audience (must match SERVICE_ID)
    if ticket.get("audience") != SERVICE_ID:
        raise ValueError("Invalid ticket audience")
        
    # 2. Validate lifetime (ticket expiration)
    if time.time() > ticket.get("expires", 0):
        raise ValueError("Ticket has expired")
        
    # 3. Validate matching client identity between ticket and authenticator
    if ticket.get("client") != auth.get("client"):
        raise ValueError("Client identity mismatch between ticket and authenticator")
        
    # 4. Validate timestamp freshness (SKEW)
    if abs(time.time() - auth.get("timestamp", 0)) > SKEW:
        raise ValueError("Authenticator timestamp is not fresh (skew exceeded)")
        
    # 5. Replay protection using replay_cache
    now = time.time()
    # Remove expired replay_cache entries
    expired_keys = [k for k, exp in replay_cache.items() if exp < now]
    for k in expired_keys:
        del replay_cache[k]
        
    # Construct a unique tuple representing the request
    session_key = ticket.get("session_key")
    client_id = auth.get("client")
    timestamp = auth.get("timestamp")
    replay_key = (session_key, client_id, timestamp)
    
    # Reject a repeated tuple
    if replay_key in replay_cache:
        raise ValueError("Replay attack detected: duplicate authenticator")
        
    # Store accepted tuple with the ticket expiry
    replay_cache[replay_key] = ticket.get("expires")
    
    # Log successful validation with log_payload()
    log_payload("SERVICE: validation successful for client", {"client": client_id})

def handle(message):
    if message["type"] != "AP_REQ":
        raise ValueError("Expected AP_REQ")
    ticket = decrypt(SERVICE_KEY, message["ticket"])
    log_payload("RECEIVED service ticket: decrypted contents", ticket)
    auth = decrypt(ticket["session_key"], message["authenticator"])
    log_payload("RECEIVED authenticator: decrypted contents", auth)
    validate_service(ticket, auth)
    reply = {"timestamp": auth["timestamp"], "message": "Printer access granted"}
    log_payload("CREATED service response: before encryption (local view)", reply)
    return {"ok": True, "reply": encrypt(ticket["session_key"], reply)}

if __name__ == "__main__":
    serve(SERVICE_PORT, handle)
